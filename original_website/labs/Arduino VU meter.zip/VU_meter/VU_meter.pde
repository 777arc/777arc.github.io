#define NUMBEROFSAMPLES 20

//global variables
float sum = 0;        //used to "integrate" the audio signal
int i = 0;            //keeps track of summed samples

void setup() {
    pinMode(2, OUTPUT);    //these set digital pins 2,3,4,5,6 to be outputs
    pinMode(3, OUTPUT);    //make sure they are the ones connects to LEDs!!!
    pinMode(4, OUTPUT);
    pinMode(5, OUTPUT);
    pinMode(6, OUTPUT);
}  

void loop() { 
  sum += analogRead(A0);
  i++;
  if (i == NUMBEROFSAMPLES)
  {  
      if (sum > NUMBEROFSAMPLES * 140)
      {
        digitalWrite(2, HIGH);
        digitalWrite(3, HIGH);
        digitalWrite(4, HIGH);
        digitalWrite(5, HIGH);
        digitalWrite(6, HIGH);
      }
      else if (sum > NUMBEROFSAMPLES * 110)
      {
        ...  //fill this in 
      }
      else if (sum > NUMBEROFSAMPLES * 80)
      {
        ...   //fill this in
      }
      
      //2 more else ifs go here
      
      sum = 0;  //reset sum
      i = 0;    //reset i
  }
}
