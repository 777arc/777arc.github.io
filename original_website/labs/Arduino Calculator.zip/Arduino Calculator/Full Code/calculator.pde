struct EQUPARTS {
  char firstnum;
  char operation;
  char secondnum;
};


void setup() {
  Serial.begin(9600);
}

void loop() {
  EQUPARTS input;
  float answer;
  while (1 == 1){
    if (Serial.available() >= 3){
      input.firstnum = Serial.read();
      input.operation = Serial.read();
      input.secondnum = Serial.read();
     
       
     
     switch (input.operation) {
        case '+':
          answer = (input.firstnum - 48) + (input.secondnum - 48);
          Serial.print(answer);
          break;
        case '-':
          answer = (input.firstnum - 48) - (input.secondnum - 48);
          Serial.print(answer);
          break;
        case '*':
          answer = (input.firstnum - 48) * (input.secondnum - 48);
          Serial.print(answer);
          break;
        case '/':
          answer = float(input.firstnum - 48) / float(input.secondnum - 48);
          Serial.print(answer);
          break;
        default: 
          Serial.print("INVALID");
      }
      Serial.flush();
      Serial.println();

    }
  }
}



