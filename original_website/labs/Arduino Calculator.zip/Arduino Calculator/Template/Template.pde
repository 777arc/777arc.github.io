void setup() {
  Serial.begin(9600);
}

void loop() {
  while (1 == 1){
    if (Serial.available() >= 3){  //checks to see if there are 3 characters in the buffer

      
      Serial.flush();      //clears the buffer, incase someone puts 4 characters by accident
      Serial.println();    //makes a new line
    }
  }
}



